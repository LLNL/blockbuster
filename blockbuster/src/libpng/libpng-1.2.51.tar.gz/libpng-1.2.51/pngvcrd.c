/* pngvcrd.c
 *
 * Last changed in libpng 1.2.48 [March 8, 2012]
 * Copyright (c) 1998-2012 Glenn Randers-Pehrson
 *
 * This code is released under the libpng license.
 * For conditions of distribution and use, see the disclaimer
 * and license in png.h
 *
 * This nearly empty file is for use by configure's compilation test. The
 * remainder of the file  was removed from libpng-1.2.20.
 */
