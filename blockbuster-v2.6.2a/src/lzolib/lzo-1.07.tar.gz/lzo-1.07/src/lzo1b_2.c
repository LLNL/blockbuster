#define COMPRESS_ID		2

#define DDBITS			0
#define CLEVEL			2
#include "compr1b.h"

